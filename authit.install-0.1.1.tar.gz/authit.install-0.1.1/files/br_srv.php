<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
 </head> 

<body bgcolor="lightgrey"> 
<form method="post">

<big><b>Службы</big></b>

<table>
<?php
$content = file ('/etc/authit.conf');
foreach ($content as $line) { // читаем построчно
    $result = explode ('=', $line); // разбиваем строку и записываем в массив
    if (trim($result[0]) == 'sqlpass') // проверка на совпадение
        $sqlpass = trim($result[1]);
}
$dbconn = pg_pconnect("host=localhost dbname=authit user=authit password=".$sqlpass);
echo pg_last_error();

	$zapros = pg_query($dbconn, "SELECT * FROM services ORDER BY srv");
	echo pg_last_error();
	$vsego_strok = pg_num_rows($zapros);
	$i=1;
	while ($vyvod = pg_fetch_array($zapros)) {
		echo '<tr>
		<td>'.$vyvod["srv"].'</td><td><a href="rem_srv.php?id='.$vyvod["id"].'" title="Удалить"><img src="rem.png" height="60%" width="60%" alt="Удалить"></a></td>';
		$i++;
		} ?>
        
        
</table>

<table>
<tr>
            <td><input name="newsrv"></td> <td><input type="submit" formmethod="POST" formaction="add_srv.php" value="+"></td>
</tr>
</table>

</form>

</body>
</html>
