<?php
$content = file ('/etc/authit.conf');
foreach ($content as $line) { // читаем построчно
    $result = explode ('=', $line); // разбиваем строку и записываем в массив
    if (trim($result[0]) == 'sqlpass') // проверка на совпадение
        $sqlpass = trim($result[1]);
}
$dbconn = pg_pconnect("host=localhost dbname=authit user=authit password=".$sqlpass);
$remsrv = pg_query($dbconn, "DELETE FROM srvuse WHERE srv=".$_GET['id'].";");
$zapros = pg_query($dbconn, "DELETE FROM services WHERE id=".$_GET['id'].";");

echo '<script>alert("Служба удалена")</script>';

header('Location: br_srv.php');
exit;

?>
