<?php

$newsrv = '';

$newsrv =  $_POST['newsrv'];

if ($newsrv) {
    $content = file ('/etc/authit.conf');
    foreach ($content as $line) { // читаем построчно
        $result = explode ('=', $line); // разбиваем строку и записываем в массив
        if (trim($result[0]) == 'sqlpass') // проверка на совпадение
            $sqlpass = trim($result[1]);
    }
    $dbconn = pg_pconnect("host=localhost dbname=authit user=authit password=".$sqlpass);
    $qwe = "INSERT INTO services (srv) VALUES ('".$newsrv ."')";
    $r = pg_query($dbconn, $qwe);
}

header('Location: br_srv.php');
exit;

?>
