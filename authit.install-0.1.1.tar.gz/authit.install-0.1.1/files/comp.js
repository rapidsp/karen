// Указан ли пароль root
function EnDo() {
    if (document.getElementById("passwd")) {
        document.getElementById("goset").disabled = false ;
        document.getElementById("nopasswd").hidden = true;
        }
 }  

// Вид аутентификации
 var auth_type = function() {
     // Если Openssl
     if (document.getElementsByName("authtype")[0].checked) {
        document.getElementsByName("radserver")[0].disabled = true
        document.getElementsByName("radpass")[0].disabled = true
        document.getElementsByName("cacert")[0].disabled = false
        document.getElementsByName("cacrl")[0].disabled = false
        document.getElementsByName("instdrv")[0].disabled = false
        document.getElementsByName("drvpth")[0].disabled = false
               }
      // Если OTP         
    else if (document.getElementsByName("authtype")[1].checked) {
        document.getElementsByName("radserver")[0].disabled = false
        document.getElementsByName("radpass")[0].disabled = false
        document.getElementsByName("cacert")[0].disabled = true
        document.getElementsByName("cacrl")[0].disabled = true
        document.getElementsByName("instdrv")[0].disabled = true
        document.getElementsByName("drvpth")[0].disabled = true
        } ;
}     
 
 // Доступ к выбору служб
 var is_srvs = function() {
     // Если ко всему ПК
     if  (document.getElementsByName("fullpc")[0].checked) {
         var srvcheck = document.getElementsByClassName('srvs')
         for (var i = 0; i < srvcheck.length; i++)
             srvcheck[i].disabled = true
         document.getElementsByName("addsrv")[0].disabled = true
     }
     // Для определенных служб
     else if (document.getElementsByName("fullpc")[1].checked) {
         var srvcheck = document.getElementsByClassName('srvs')
         for (var i = 0; i < srvcheck.length; i++)
             srvcheck[i].disabled = false
         document.getElementsByName("addsrv")[0].disabled = false           
     }
 }

 function load_comp() {
     auth_type()
     is_srvs()
 }
